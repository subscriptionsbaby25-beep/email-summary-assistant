import { summarizeEmails } from "@/src/api/utils/summarizer";

export default async function handler(req, res) {
  try {
    // Fetch emails for all active users (mock)
    const mockEmails = [
      { subject: "Project Update", body: "We need the new logo by Friday." },
      { subject: "Invoice Reminder", body: "Payment due by 10th." }
    ];

    const summary = await summarizeEmails(mockEmails);

    // Here you’d email the summary to the user using SendGrid
    console.log("Summary generated:", summary);

    res.status(200).json({ success: true, summary });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: e.message });
  }
}
