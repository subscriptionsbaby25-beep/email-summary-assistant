import OpenAI from "openai";

export async function summarizeEmails(threads) {
  const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
  const prompt = `Summarize the following email threads into concise bullet points (≤3 per thread).
Extract tasks, deadlines, and next steps.`;

  const response = await client.chat.completions.create({
    model: "gpt-4o-mini",
    messages: [{ role: "user", content: `${prompt}\n${JSON.stringify(threads)}` }],
  });

  return response.choices[0].message.content;
}
