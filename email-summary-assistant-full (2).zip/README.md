# Email Summary Assistant (MVP)
A minimal, production-ready AI SaaS starter for automated email digests.

## Features
- Gmail/Outlook integration
- Daily AI-generated summaries
- Stripe subscription support
- Serverless cron jobs

## Setup
1. Copy `.env.local.example` to `.env.local` and fill in API keys.
2. Run `npm install`
3. Run `npm run dev`
4. Deploy to Vercel or AWS Lambda

## License
MIT License
